export interface Adresse {
  ville: string;
  codePostal: number;
  rue: string;
  numero: string;
  etage: string;
  lat: number;
  lng: number;
}
